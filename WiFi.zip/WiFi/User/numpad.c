#include "numpad.h"
#include "./lcd/bsp_xpt2046_lcd.h"
#include "./lcd/bsp_ili9341_lcd.h"
#include "./relay/bsp_relay.h"
#include "./dht11/bsp_dht11.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "ff.h"

Touch_Button button[BUTTON_NUM];
char Input[10];
static int count = 0;
extern void jpgDisplay(char *pic_name);

void delayus(int duration);


static void Draw_Number_Button(void *btn);
static void Draw_Delete_Button(void *btn);
static void Draw_OK_Button(void *btn);
static void Draw_Input_Window(char* input);

static void Command_Select_Number(char* input, void * btn);
static void Command_Select_Delete(char* input, void * btn);
static void Command_Select_OK(char* input, void * btn);
static void Command_Clear_Password(char* input);


void Numpad_Init(uint8_t LCD_Mode)
{
	uint8_t i;
	

	ILI9341_GramScan ( LCD_Mode );
	
	/* Clear the whole screen */
	LCD_SetBackColor(CL_WHITE);
  ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	
	
	Touch_Button_Init();
	
	LCD_SetFont(&Font8x16);
	ILI9341_DispString_EN(0,0, "Please type your password :"); 
	
	for(i=0;i<BUTTON_NUM;i++)
	{
		button[i].draw_btn(&button[i]);
	}
	
	
}

void Touch_Button_Init(void)
{
	/* Button[0-9], represents 1,2,3,4,5,6,7,8,9 */
	button[0].value = '1';
	button[0].start_x = BUTTON_START_X;
  button[0].start_y = BUTTON_START_Y;
  button[0].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[0].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT;
  button[0].para = CL_BLACK;
  button[0].touch_flag = 0;  
  button[0].draw_btn = Draw_Number_Button ;
  button[0].btn_command = Command_Select_Number;
	
	button[1].value = '2';
	button[1].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[1].start_y = BUTTON_START_Y;
  button[1].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2 ;
  button[1].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT;
  button[1].para = CL_BLACK;
  button[1].touch_flag = 0;  
  button[1].draw_btn = Draw_Number_Button;
  button[1].btn_command = Command_Select_Number;
	
	button[2].value = '3';
	button[2].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[2].start_y = BUTTON_START_Y;
  button[2].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*3 ;
  button[2].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT;
  button[2].para = CL_BLACK;
  button[2].touch_flag = 0;  
  button[2].draw_btn = Draw_Number_Button;
  button[2].btn_command = Command_Select_Number;
	
	button[3].value = '4';
	button[3].start_x = BUTTON_START_X;
  button[3].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT;
  button[3].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[3].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*2;
  button[3].para = CL_BLACK;
  button[3].touch_flag = 0;  
  button[3].draw_btn = Draw_Number_Button;
  button[3].btn_command = Command_Select_Number;
	
	button[4].value = '5';
	button[4].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[4].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT;
  button[4].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2 ;
  button[4].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*2;
  button[4].para = CL_BLACK;
  button[4].touch_flag = 0;  
  button[4].draw_btn = Draw_Number_Button;
  button[4].btn_command = Command_Select_Number;
	
	button[5].value = '6';
	button[5].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[5].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT;
  button[5].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*3;
  button[5].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*2;
  button[5].para = CL_BLACK;
  button[5].touch_flag = 0;  
  button[5].draw_btn = Draw_Number_Button;
  button[5].btn_command = Command_Select_Number;
	
	button[6].value = '7';
	button[6].start_x = BUTTON_START_X;
  button[6].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*2;
  button[6].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[6].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*3;
  button[6].para = CL_BLACK;
  button[6].touch_flag = 0;  
  button[6].draw_btn = Draw_Number_Button;
  button[6].btn_command = Command_Select_Number;
	
	button[7].value = '8';
	button[7].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[7].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*2;
  button[7].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[7].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*3;
  button[7].para = CL_BLACK;
  button[7].touch_flag = 0;  
  button[7].draw_btn = Draw_Number_Button;
  button[7].btn_command = Command_Select_Number;
	
	button[8].value = '9';
	button[8].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[8].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*2;
  button[8].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*3;
  button[8].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*3;
  button[8].para = CL_BLACK;
  button[8].touch_flag = 0;  
  button[8].draw_btn = Draw_Number_Button;
  button[8].btn_command = Command_Select_Number;	
	
	button[9].value = '*';
	button[9].start_x = BUTTON_START_X;
  button[9].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*3;
  button[9].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[9].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*4;
  button[9].para = CL_BLACK;
  button[9].touch_flag = 0;  
  button[9].draw_btn = Draw_Number_Button;
  button[9].btn_command = Command_Select_Number;
	
	button[10].value = '0';
	button[10].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[10].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*3;
  button[10].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[10].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*4;
  button[10].para = CL_BLACK;
  button[10].touch_flag = 0;  
  button[10].draw_btn = Draw_Number_Button;
  button[10].btn_command = Command_Select_Number;
	
	button[11].value = '#';
	button[11].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[11].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*3;
  button[11].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*3;
  button[11].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*4;
  button[11].para = CL_BLACK;
  button[11].touch_flag = 0;  
  button[11].draw_btn = Draw_Number_Button;
  button[11].btn_command = Command_Select_Number;		
	
	button[12].value = 'd';
	button[12].start_x = BUTTON_START_X;
  button[12].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*4;
  button[12].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH;
  button[12].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*5;
  button[12].para = CL_RED;
  button[12].touch_flag = 0;  
  button[12].draw_btn = Draw_Delete_Button;
  button[12].btn_command = Command_Select_Delete;
	
	button[13].value = 'k';
	button[13].start_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*2;
  button[13].start_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*4;
  button[13].end_x = BUTTON_START_X+NUMBER_BLOCK_WIDTH*3;
  button[13].end_y = BUTTON_START_Y+NUMBER_BLOCK_HEIGHT*5;
  button[13].para = CL_RED;
  button[13].touch_flag = 0;  
  button[13].draw_btn = Draw_OK_Button;
  button[13].btn_command = Command_Select_OK;
}

void Touch_Button_Down(uint16_t x,uint16_t y)
{
	 uint8_t i;
	 for(i=0;i<BUTTON_NUM;i++)
	{
		if(x<=button[i].end_x && y<=button[i].end_y && y>=button[i].start_y && x>=button[i].start_x )
    {
      if(button[i].touch_flag == 0)    
      {
      button[i].touch_flag = 1;       
      
      button[i].draw_btn(&button[i]);  
      }        
      
    }
    else if(button[i].touch_flag == 1) 
    {
      button[i].touch_flag = 0;     
      
      button[i].draw_btn(&button[i]);  
    }
	}
}

void Touch_Button_Up(uint16_t x,uint16_t y, char* input)
{
   uint8_t i; 
   for(i=0;i<BUTTON_NUM;i++)
   {
     /* �����ڰ�ť�����ͷ� */
      if((x<button[i].end_x && x>button[i].start_x && y<button[i].end_y && y>button[i].start_y))
      {        
        button[i].touch_flag = 0;     
        
        button[i].draw_btn(&button[i]);       
      
        button[i].btn_command(input, &button[i]);  
        
        break;
      }
    }  

}


static void Draw_Delete_Button(void *btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	/* Release the button*/
	if(ptr->touch_flag == 0)
	{
		LCD_SetColors(ptr->para,CL_WHITE);
		LCD_SetFont(&Font16x24);
		ILI9341_DispString_EN( ptr->start_x, ptr->start_y, "Del");
	}
	else
	{
		LCD_SetColors(CL_BLACK,CL_WHITE);
	}
	
	/*Button border*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);
	ILI9341_DrawRectangle(	ptr->start_x,
													ptr->start_y,
													ptr->end_x - ptr->start_x,
													ptr->end_y - ptr->start_y,0);
}

static void Draw_OK_Button(void *btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	/* Release the button*/
	if(ptr->touch_flag == 0)
	{
		LCD_SetColors(ptr->para,CL_WHITE);
		LCD_SetFont(&Font16x24);
		ILI9341_DispString_EN( ptr->start_x, ptr->start_y, "OK");
	}
	else
	{
		LCD_SetColors(CL_BLACK,CL_WHITE);
	}
	
	/*Button border*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);
	ILI9341_DrawRectangle(	ptr->start_x,
													ptr->start_y,
													ptr->end_x - ptr->start_x,
													ptr->end_y - ptr->start_y,0);
}

static void Draw_Number_Button(void *btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	/* Release the button*/
	if(ptr->touch_flag == 0)
	{
		LCD_SetColors(ptr->para,CL_WHITE);
		LCD_SetFont(&Font16x24);
		ILI9341_DispChar_EN( ptr->start_x, ptr->start_y, ptr->value); //(char)ptr->value
	}
	else
	{
		LCD_SetColors(CL_BLACK,CL_WHITE);
	}
	
	/*Button border*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);
	ILI9341_DrawRectangle(	ptr->start_x,
													ptr->start_y,
													ptr->end_x - ptr->start_x,
													ptr->end_y - ptr->start_y,0);
}
	
static void Command_Select_Number(char* input, void * btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	input[count] = ptr->value;
	count += 1;
	input[count] += '\0';
	
	Draw_Input_Window(input);
}

static void Command_Select_Delete(char* input, void * btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	if(ptr->value == 'd'){
		
		count -= 1;
		input[count] = '\0';
		Draw_Input_Window(input);
	}
}

static void Command_Select_OK(char* input, void * btn)
{
	Touch_Button *ptr = (Touch_Button *)btn;
	
	DHT11_Data_TypeDef DHT11_Data;
	
	if(ptr->value == 'k'){
		if(((strlen(input)) == (strlen(PASSWORD))) && (strcmp(input, PASSWORD)==0)){
			/* Unlock Action */
			LCD_SetColors(CL_WHITE,CL_WHITE);
			ILI9341_DrawRectangle(0, 70, LCD_X_LENGTH, 40, 1);
			
			LCD_SetColors(CL_RED,CL_WHITE);
			LCD_SetFont(&Font8x16);
			ILI9341_DispString_EN(50, 80, "Correct Password!");
			/* Unlock + outscreen */
			delayus(1000000);
			jpgDisplay("0:/success.jpg");
			delayus(1000000);
			RELAY1_ON;
			delayus(5000000);
			RELAY1_OFF;
			//Smart_Relay(TEMPERATURE, HUMIDITY);
				
		}
		else{
			/* Incorrect Action */
			LCD_SetColors(CL_WHITE,CL_WHITE);
			ILI9341_DrawRectangle(0, 70, LCD_X_LENGTH, 40, 1);
			
			LCD_SetColors(CL_RED,CL_WHITE);
			LCD_SetFont(&Font8x16);
			ILI9341_DispString_EN(50, 80, "Incorrect Password!");
			Command_Clear_Password(input);
			delayus(1000000);
			jpgDisplay("0:/fail.jpg");
			delayus(2000000);
			Numpad_Init(LCD_SCAN_MODE);
		}
	}
}

static void Command_Clear_Password(char* input)
{
	int i;
	for(i=0; i<count; i++)
	{
		input[i] = '\0';
	}
	//input[0] = '\0';
	count = 0;
}


static void Draw_Input_Window(char* input)
{
	LCD_SetColors(CL_WHITE,CL_WHITE);
	ILI9341_DrawRectangle(0, 70, LCD_X_LENGTH, 40, 1);
	
	LCD_SetColors(CL_BUTTON_GREY,CL_WHITE);
	ILI9341_DrawRectangle(40, 70, 120, 40, 0);
	LCD_SetColors(CL_RED,CL_BUTTON_GREY);
	LCD_SetFont(&Font8x16);
	ILI9341_DispString_EN(50, 80, input);
}

void Change_Password(uint16_t new_password)
{
	/* Change password */
}

void delayus(int duration)
{
		while(duration--) 
		{
			int i=0x02;				
			while(i--)
			__asm("nop");
		}
}
