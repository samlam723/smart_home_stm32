#ifndef __SDIO_TEST_H
#define __SDIO_TEST_H

void SD_Test(void);

#endif


/*****************************END OF FILE**************************/
