#ifndef __RELAY_H
#define	__RELAY_H


#include "stm32f10x.h"



#define RELAY1_GPIO_PORT    	GPIOB			              
#define RELAY1_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define RELAY1_GPIO_PIN		    GPIO_Pin_12	        

#define RELAY2_GPIO_PORT    	GPIOB			              
#define RELAY2_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define RELAY2_GPIO_PIN		    GPIO_Pin_13	

#define RELAY3_GPIO_PORT    	GPIOB			              
#define RELAY3_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define RELAY3_GPIO_PIN		    GPIO_Pin_14

#define RELAY4_GPIO_PORT    	GPIOB			              
#define RELAY4_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define RELAY4_GPIO_PIN		    GPIO_Pin_15	

/* ֱ�Ӳ����Ĵ����ķ�������IO */
#define	digitalHi(p,i)		 {p->BSRR=i;}	 //���Ϊ�ߵ�ƽ		
#define digitalLo(p,i)		 {p->BRR=i;}	 //����͵�ƽ
#define digitalToggle(p,i) {p->ODR ^=i;} //�����ת״̬


/* �������IO�ĺ� */
#define RELAY1_TOGGLE		 digitalToggle(RELAY1_GPIO_PORT,RELAY1_GPIO_PIN)
#define RELAY1_ON		   digitalHi(RELAY1_GPIO_PORT,RELAY1_GPIO_PIN)
#define RELAY1_OFF			   digitalLo(RELAY1_GPIO_PORT,RELAY1_GPIO_PIN)

#define RELAY2_TOGGLE		 digitalToggle(RELAY2_GPIO_PORT,RELAY2_GPIO_PIN)
#define RELAY2_ON		   digitalHi(RELAY2_GPIO_PORT,RELAY2_GPIO_PIN)
#define RELAY2_OFF			   digitalLo(RELAY2_GPIO_PORT,RELAY2_GPIO_PIN)

#define RELAY3_TOGGLE		 digitalToggle(RELAY3_GPIO_PORT,RELAY3_GPIO_PIN)
#define RELAY3_ON		   digitalHi(RELAY3_GPIO_PORT,RELAY3_GPIO_PIN)
#define RELAY3_OFF			   digitalLo(RELAY3_GPIO_PORT,RELAY3_GPIO_PIN)

#define RELAY4_TOGGLE		 digitalToggle(RELAY4_GPIO_PORT,RELAY4_GPIO_PIN)
#define RELAY4_ON		   digitalHi(RELAY4_GPIO_PORT,RELAY4_GPIO_PIN)
#define RELAY4_OFF			   digitalLo(RELAY4_GPIO_PORT,RELAY4_GPIO_PIN)

extern uint8_t ucLed1Status, ucLed2Status, ucLed3Status, ucBuzzerStatus;
extern uint8_t ucRelay1Status, ucRelay2Status, ucRelay3Status, ucRelay4Status;

void RELAY_GPIO_Config(void);

#endif /* __RELAY_H */
