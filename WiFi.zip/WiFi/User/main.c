#include "stm32f10x.h"
#include "./usart/bsp_usart.h"	
#include "./usart/rx_data_queue.h"
#include "./lcd/bsp_ili9341_lcd.h"
#include "./lcd/bsp_xpt2046_lcd.h"
#include "./flash/bsp_spi_flash.h"
#include "./led/bsp_led.h"  
#include "./key/bsp_key.h"  
#include "./relay/bsp_relay.h"
#include "./tpad/bsp_tpad.h" 
#include "./beep/bsp_beep.h"
#include "./as608/as608_test.h"
#include "./as608/bsp_as608.h"
#include "./bmp/bsp_bmp.h"
#include "./ov7725/bsp_ov7725.h"
#include "./systick/bsp_SysTick.h"
#include "./dht11/bsp_dht11.h"
#include "./esp8266/bsp_esp8266.h"
#include "./test/test.h"
#include "ff.h"
#include "numpad.h"
#include <stdio.h>
#include <time.h> 

void test_camera(void);
void DELAYUS(int duration);
unsigned int Task_Delay[NumOfTask]; 
extern void jpgDisplay(char *pic_name);
extern OV7725_MODE_PARAM cam_mode;
extern uint8_t Ov7725_vsync;
extern uint8_t ucLed1Status, ucLed2Status, ucLed3Status, ucBuzzerStatus;
extern uint8_t ucRelay1Status, ucRelay2Status, ucRelay3Status, ucRelay4Status;


FATFS fs;													
FRESULT res_sd;               




/**
  * @brief  main
  * @param  -  
  * @retval -
  */
int main ( void )
{
	float frame_count = 0;
	uint8_t retry = 0;
	uint8_t i;
	DHT11_Data_TypeDef DHT11_Data;
	uint8_t ucId, ucLen;
	char cStr [ 100 ] = { 0 }, cCh;
  char * pCh, * pCh1;
	uint8_t ucLed1Status = 0, ucLed2Status = 0, ucLed3Status = 0, ucBuzzerStatus = 0;
  uint8_t ucRelay1Status = 0 , ucRelay2Status = 0, ucRelay3Status = 0, ucRelay4Status = 0;
	
	USART_Config();		
	SysTick_Init ();                                                               //SysTick: 1ms break one time
	LED_GPIO_Config();
	Key_GPIO_Config();
	RELAY_GPIO_Config ();
	Beep_GPIO_Config();
	DHT11_Init ();
	
	
	
	if(  DHT11_Read_TempAndHumidity ( & DHT11_Data ) == SUCCESS)
	{
		printf("\r\nReading DHT11 successful!\r\n\r\nHumidity is %d.%d ��RH, Temperature is %d.%d�� \r\n",\
		DHT11_Data.humi_int,DHT11_Data.humi_deci,DHT11_Data.temp_int,DHT11_Data.temp_deci);
		if (DHT11_Data.humi_int > 50)
			RELAY2_ON;
			DELAYUS(5000000);
			RELAY2_OFF;
		if (DHT11_Data.temp_int > 20)
			RELAY3_ON;
			DELAYUS(5000000);
			RELAY3_OFF;
	}
	else
	{
		printf("Read DHT11 ERROR!\r\n");
	}
	
	ESP8266_Init ();
	ESP8266_StaTcpClient_UnvarnishTest ();
	
	ILI9341_Init ();         //LCD init
	ILI9341_GramScan ( 3 );
	
	LCD_SetFont(&Font8x16);
	LCD_SetColors(RED,BLACK);
  ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	/* All black */
	
	
		for ( i = 0; i<50; i++)
	{
		TPAD_Init();
	}

	ILI9341_GramScan ( 6 );

	
	res_sd = f_mount(&fs,"0:",1);
	if(res_sd != FR_OK)
	{
		printf("\r\ninsert sd card\r\n");
	}
	

	
	/*init*/
  rx_queue_init();
   
  /*fingerprint*/
	AS608_Config();
  
	/*communication between stm32*/
  Connect_Test();
	
	
	printf("\r\n ********** JPG*********** \r\n"); 
	printf("\r\n hi, \r\n"); 
	
	ILI9341_GramScan ( 6 );
	
	
	//touch screen init
	XPT2046_Init();
	//FLASH
	Calibrate_or_Get_TouchParaWithFlash(3,0);
	
	RELAY_GPIO_Config ();
	
	
	jpgDisplay("0:/intro.jpg");
	DELAYUS(2000000);
	jpgDisplay("0:/mode.jpg");
	DELAYUS(2000000);
	
	
		
	

	while ( 1 )
	{
		
	//	XPT2046_TouchEvenHandler();
		
		if( Key_Scan(KEY1_GPIO_PORT,KEY1_GPIO_PIN) == KEY_ON  )
		{	
				Numpad_Init(LCD_SCAN_MODE);
		}
		if( Key_Scan(KEY2_GPIO_PORT,KEY2_GPIO_PIN) == KEY_ON  )
		{	
				Compare_FR();
		}
		
	}
	
}

void DELAYUS(int duration)
{

		while(duration--) 
		{
			int i=0x02;				
			while(i--)
			__asm("nop");
		}
}



/* ------------------------------------------end of file---------------------------------------- */

