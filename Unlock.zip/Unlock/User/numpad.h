#ifndef _NUMPAD_H
#define _NUMPAD_H

#include "stm32f10x.h"

#define NUMBER_BLOCK_WIDTH 80
#define NUMBER_BLOCK_HEIGHT 40

#define BUTTON_NUM 14
#define NUMPAD_START_Y   0
#define NUMPAD_END_Y     LCD_Y_LENGTH


#define NUMBER_START_X   (NUMBER_BLOCK_WIDTH*2+1)
#define NUMBER_END_X     LCD_X_LENGTH

#define BUTTON_START_X      0
#define BUTTON_START_Y   119
#define BUTTON_END_X		 LCD_X_LENGTH
#define BUTTON_END_Y     LCD_Y_LENGTH

#define PASSWORD				 "0000"
extern char Input[10];


#if LCD_RGB_888
#define RGB(R,G,B)	( (R<< 16) | (G << 8) | (B))	

#else 
#define RGB(R,G,B)	(((R >> 3) << 11) | ((G >> 2) << 5) | (B >> 3))	
#define RGB565_R(x)  ((x >> 8) & 0xF8)
#define RGB565_G(x)  ((x >> 3) & 0xFC)
#define RGB565_B(x)  ((x << 3) & 0xF8)

#endif

enum
{
	CL_WHITE    = RGB(255,255,255),	
	CL_BLACK    = RGB(  0,  0,  0),	
	CL_RED      = RGB(255,	0,  0),	
	CL_GREEN    = RGB(  0,255,  0),	
	CL_BLUE     = RGB(  0,	0,255),	
	CL_YELLOW   = RGB(255,255,  0),	

	CL_GREY    = RGB( 98, 98, 98), 	
	CL_GREY1		= RGB( 150, 150, 150), 	
	CL_GREY2		= RGB( 180, 180, 180), 	
	CL_GREY3		= RGB( 200, 200, 200), 
	CL_GREY4		= RGB( 230, 230, 230), 

	CL_BUTTON_GREY	= RGB( 195, 195, 195), 

	CL_MAGENTA      = RGB(255, 0, 255),
	CL_CYAN         = RGB( 0, 255, 255),	

	CL_BLUE1        = RGB(  0,  0, 240),		
	CL_BLUE2        = RGB(  0,  0, 128),		
	CL_BLUE3        = RGB(  68, 68, 255),		
	CL_BLUE4        = RGB(  0, 64, 128),		

	
	CL_BTN_FACE		  = RGB(236, 233, 216),	
	CL_BOX_BORDER1	= RGB(172, 168,153),	
	CL_BOX_BORDER2	= RGB(255, 255,255),	

	CL_MASK			    = 0x7FFF	
};

typedef struct 
{
  char value;
	uint16_t start_x; 
  uint16_t start_y;  
  uint16_t end_x;      
  uint16_t end_y;    
  uint32_t para;     
  uint8_t touch_flag; 
    
  void (*draw_btn)(void * btn);  
  void (*btn_command)(char* input, void * btn);  
 
}Touch_Button;

void Numpad_Init(uint8_t LCD_Mode);
void Touch_Button_Init(void);
void Touch_Button_Down(uint16_t x,uint16_t y);
void Touch_Button_Up(uint16_t x,uint16_t y, char* input);
void Change_Password(uint16_t new_password);


#endif //_NUMPAD_H

