#include "welcome_screen.h"
#include "numpad.h"
#include "./lcd/bsp_xpt2046_lcd.h"
#include "./lcd/bsp_ili9341_lcd.h"
#include <string.h>

Mode_Button mode_button[MODE_BUTTON_NUM];
Unlock_Button unlock_button[UNLOCK_BUTTON_NUM];
Setting_Button setting_button[SETTING_BUTTON_NUM];

static void Draw_Mode_Button(void *btn);
static void Draw_Unlock_Button(void *btn);
static void Draw_Setting_Button(void *btn);

static void Command_Select_Mode(void * btn);
static void Command_Select_Unlock(void * btn);
static void Command_Select_Setting(void * btn);

int page = 0;

void Welcome_Screen_Init(void)
{
	uint8_t i;
	
	
	LCD_SetBackColor(CL_WHITE);
	ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	
	
	/*
	LCD_SetFont(&Font16x24);
	ILI9341_DispString_EN(0,0, "ELEC3300"); 
	ILI9341_DispString_EN(0,25, "Group3"); 
	
	LCD_SetColors(RGB(150, 0, 150),CL_WHITE);
	LCD_SetFont(&Font8x16);
	ILI9341_DispString_EN(100, 55, "Lam King Sum, Sam");
	ILI9341_DispString_EN(85, 71, "Cheung Ka Yi, Grace");
	
	LCD_SetColors(CL_RED,CL_WHITE);
	ILI9341_DrawRectangle(45, 145, 150, 30, 0);
	LCD_SetFont(&Font8x16);
	LCD_SetColors(CL_BLUE3,CL_WHITE);
	ILI9341_DispString_EN(50, 150, "Smart Lock System");
	
	ILI9341_DispString_EN(50, 150, "Menu : ");
	ILI9341_DispString_EN(50, 150, "1. Unlock ");
	ILI9341_DispString_EN(50, 150, "2. Settings");
	
	
	ILI9341_DispString_EN(50, 150, "1. Unlock by Optical Fingerprint sensor  ");
	ILI9341_DispString_EN(50, 150, "2. Unlock by RFID card  ");
	ILI9341_DispString_EN(50, 150, "3. Unlock by Password  ");
	
	ILI9341_DispString_EN(50, 150, "1. Optical Fingerprint ");
	ILI9341_DispString_EN(50, 150, "2. RFID");
	ILI9341_DispString_EN(50, 150, "3. Password  ");
	*/
	
	
	Mode_Screen_Init();
	
	
	
}

void Mode_Screen_Init(void)
{
	uint8_t i;
	
	LCD_SetBackColor(CL_WHITE);
	ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	
	
	LCD_SetFont(&Font16x24);
	ILI9341_DispString_EN(5, 5, "Mode: ");
	
	for(i=0;i<MODE_BUTTON_NUM;i++)
	{
		mode_button[i].draw_btn(&mode_button[i]);
	}
	
}
void Unlock_Screen_Init(void)
{
	uint8_t i;
	
	LCD_SetBackColor(CL_WHITE);
	ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	
	
	LCD_SetFont(&Font16x24);
	ILI9341_DispString_EN(5, 5, "Unlock options: ");
	
	for(i=0;i<UNLOCK_BUTTON_NUM;i++)
	{
		unlock_button[i].draw_btn(&unlock_button[i]);
	}
}

void Setting_Screen_Init(void)
{
	uint8_t i;
	
	
	LCD_SetBackColor(CL_WHITE);
	ILI9341_Clear(0,0,LCD_X_LENGTH,LCD_Y_LENGTH);	
	
	LCD_SetFont(&Font16x24);
	ILI9341_DispString_EN(5, 5, "Settings: ");
	
	for(i=0;i<SETTING_BUTTON_NUM;i++)
	{
		setting_button[i].draw_btn(&setting_button[i]);
	}
}
	

void Mode_Button_Init(void)
{
	mode_button[0].value = "Unlcok mode";
	mode_button[0].mode_mark = 'U';
	mode_button[0].start_x = MODE_BUTTON_START_X;
  mode_button[0].start_y = MODE_BUTTON_START_Y;
  mode_button[0].end_x = MODE_BUTTON_START_X+MODE_BUTTON_WIDTH;
  mode_button[0].end_y = MODE_BUTTON_START_Y+MODE_BUTTON_HEIGHT;
  mode_button[0].para = CL_BLACK;
  mode_button[0].touch_flag = 0;  
  mode_button[0].draw_btn = Draw_Mode_Button ;
  mode_button[0].btn_command = Command_Select_Mode;
	
	mode_button[1].value = "Setting mode";
	mode_button[1].mode_mark = 'S';
	mode_button[1].start_x = MODE_BUTTON_START_X+MODE_BUTTON_WIDTH;
  mode_button[1].start_y = MODE_BUTTON_START_Y;
  mode_button[1].end_x = MODE_BUTTON_START_X+MODE_BUTTON_WIDTH*2;
  mode_button[1].end_y = MODE_BUTTON_START_Y+MODE_BUTTON_HEIGHT;
  mode_button[1].para = CL_BLACK;
  mode_button[1].touch_flag = 0;  
  mode_button[1].draw_btn = Draw_Mode_Button ;
  mode_button[1].btn_command = Command_Select_Mode;
}

void Unlock_Button_Init(void)
{
	unlock_button[0].value = "Fingerprint";
	unlock_button[0].unlock_mark = 'F';
	unlock_button[0].start_x = UNLOCK_BUTTON_START_X;
  unlock_button[0].start_y = UNLOCK_BUTTON_START_Y;
  unlock_button[0].end_x = UNLOCK_BUTTON_START_X+UNLOCK_BUTTON_WIDTH;
  unlock_button[0].end_y = UNLOCK_BUTTON_START_Y+UNLOCK_BUTTON_HEIGHT;
  unlock_button[0].para = CL_BLACK;
  unlock_button[0].touch_flag = 0;  
  unlock_button[0].draw_btn = Draw_Unlock_Button ;
  unlock_button[0].btn_command = Command_Select_Unlock;
	
	unlock_button[1].value = "RFID" ;
	unlock_button[0].unlock_mark = 'R';
	unlock_button[1].start_x = UNLOCK_BUTTON_START_X;
  unlock_button[1].start_y = UNLOCK_BUTTON_START_Y;
  unlock_button[1].end_x = UNLOCK_BUTTON_START_X+UNLOCK_BUTTON_WIDTH;
  unlock_button[1].end_y = UNLOCK_BUTTON_START_Y+UNLOCK_BUTTON_HEIGHT;
  unlock_button[1].para = CL_BLACK;
  unlock_button[1].touch_flag = 0;  
  unlock_button[1].draw_btn = Draw_Unlock_Button ;
  unlock_button[1].btn_command = Command_Select_Unlock;
	
	unlock_button[2].value = "Password" ;
	unlock_button[0].unlock_mark = 'P';
	unlock_button[2].start_x = UNLOCK_BUTTON_START_X;
  unlock_button[2].start_y = UNLOCK_BUTTON_START_Y;
  unlock_button[2].end_x = UNLOCK_BUTTON_START_X+UNLOCK_BUTTON_WIDTH;
  unlock_button[2].end_y = UNLOCK_BUTTON_START_Y+UNLOCK_BUTTON_HEIGHT;
  unlock_button[2].para = CL_BLACK;
  unlock_button[2].touch_flag = 0;  
  unlock_button[2].draw_btn = Draw_Unlock_Button ;
  unlock_button[2].btn_command = Command_Select_Unlock;

}

void Setting_Button_Init(void)
{
	setting_button[0].value = "Fingerprint" ;
	setting_button[0].setting_mark = 'F';
	setting_button[0].start_x = SETTING_BUTTON_START_X;
  setting_button[0].start_y = SETTING_BUTTON_START_Y;
  setting_button[0].end_x = SETTING_BUTTON_START_X+SETTING_BUTTON_WIDTH;
  setting_button[0].end_y = SETTING_BUTTON_START_Y+SETTING_BUTTON_HEIGHT;
  setting_button[0].para = CL_BLACK;
  setting_button[0].touch_flag = 0;  
  setting_button[0].draw_btn = Draw_Setting_Button ;
  setting_button[0].btn_command = Command_Select_Setting;
	
	setting_button[1].value = "RFID" ;
	setting_button[1].setting_mark = 'R';
	setting_button[1].start_x = SETTING_BUTTON_START_X;
  setting_button[1].start_y = SETTING_BUTTON_START_Y;
  setting_button[1].end_x = SETTING_BUTTON_START_X+SETTING_BUTTON_WIDTH;
  setting_button[1].end_y = SETTING_BUTTON_START_Y+SETTING_BUTTON_HEIGHT;
  setting_button[1].para = CL_BLACK;
  setting_button[1].touch_flag = 0;  
  setting_button[1].draw_btn = Draw_Setting_Button ;
  setting_button[1].btn_command = Command_Select_Setting;
	
	setting_button[2].value = "Password" ;
	setting_button[2].setting_mark = 'P';
	setting_button[2].start_x = SETTING_BUTTON_START_X;
  setting_button[2].start_y = SETTING_BUTTON_START_Y;
  setting_button[2].end_x = SETTING_BUTTON_START_X+SETTING_BUTTON_WIDTH;
  setting_button[2].end_y = SETTING_BUTTON_START_Y+SETTING_BUTTON_HEIGHT;
  setting_button[2].para = CL_BLACK;
  setting_button[2].touch_flag = 0;  
  setting_button[2].draw_btn = Draw_Setting_Button ;
  setting_button[2].btn_command = Command_Select_Setting;
	
}

static void Draw_Mode_Button(void *btn)
{
	Mode_Button *ptr = (Mode_Button *)btn;
	
	/* Release the button*/
	if(ptr->touch_flag == 0)
	{
		LCD_SetColors(ptr->para,CL_WHITE);
		LCD_SetFont(&Font16x24);
		ILI9341_DispString_EN( ptr->start_x, ptr->start_y, ptr->value);
	}
	else
	{
		LCD_SetColors(CL_BLACK,CL_WHITE);
	}
	
	/*Button border*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);
	ILI9341_DrawRectangle(	ptr->start_x,
													ptr->start_y,
													ptr->end_x - ptr->start_x,
													ptr->end_y - ptr->start_y,0);
}

static void Draw_Unlock_Button(void *btn)
{
	Unlock_Button *ptr = (Unlock_Button *)btn;
	
	/* Release the button*/
	if(ptr->touch_flag == 0)
	{
		LCD_SetColors(ptr->para,CL_WHITE);
		LCD_SetFont(&Font16x24);
		ILI9341_DispString_EN( ptr->start_x, ptr->start_y, ptr->value);
	}
	else
	{
		LCD_SetColors(CL_BLACK,CL_WHITE);
	}
	
	/*Button border*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);
	ILI9341_DrawRectangle(	ptr->start_x,
													ptr->start_y,
													ptr->end_x - ptr->start_x,
													ptr->end_y - ptr->start_y,0);
}

static void Draw_Setting_Button(void *btn)
{
	Setting_Button *ptr = (Setting_Button *)btn;
	
	/* Release the button*/
	if(ptr->touch_flag == 0)
	{
		LCD_SetColors(ptr->para,CL_WHITE);
		LCD_SetFont(&Font16x24);
		ILI9341_DispString_EN( ptr->start_x, ptr->start_y, ptr->value);
	}
	else
	{
		LCD_SetColors(CL_BLACK,CL_WHITE);
	}
	
	/*Button border*/
	LCD_SetColors(CL_BLUE4,CL_WHITE);
	ILI9341_DrawRectangle(	ptr->start_x,
													ptr->start_y,
													ptr->end_x - ptr->start_x,
													ptr->end_y - ptr->start_y,0);
}

static void Command_Select_Mode(void * btn)
{
	Mode_Button *ptr = (Mode_Button *)btn;
	
	switch(ptr->mode_mark)
	{
		case('U'):
		{
			/* Go unlock mode page */
			Unlock_Screen_Init();
			
			
		}
		case('R'):
		{
			/* Go setting mode page */
			Setting_Screen_Init();
		}
	}
	
	
	
	
	
}
static void Command_Select_Unlock(void * btn)
{
	Unlock_Button *ptr = (Unlock_Button *)btn;
	
	switch(ptr->unlock_mark)
	{
		case('F'):
		{
			/* Go fingerprint unlock function */
		}
		case('R'):
		{
			/* Go RFID unlock function */
		}
		case('P'):
		{
			/* Go Password Unlock function */
			Numpad_Init(LCD_SCAN_MODE);
		}
	}
			
//	Unlock_Screen_Init(uint8_t LCD_Mode);
}


static void Command_Select_Setting(void * btn)
{
	Setting_Button *ptr = (Setting_Button *)btn;
	
	switch(ptr->setting_mark)
	{
		case('F'):
		{
			/* Go fingerprint setting function */
		}
		case('R'):
		{
			/* Go RFID setting function */
		}
		case('P'):
		{
			/* Go Password setting function */
			Numpad_Init(LCD_SCAN_MODE);
		}
	}
}

void Mode_Button_Down(uint16_t x,uint16_t y)
{
	uint8_t i;
	 for(i=0;i<MODE_BUTTON_NUM;i++)
	{
		if(x<=mode_button[i].end_x && y<=mode_button[i].end_y && y>=mode_button[i].start_y && x>=mode_button[i].start_x )
    {
      if(mode_button[i].touch_flag == 0)     /*ԭ����״̬Ϊû�а��£������״̬*/
      {
      mode_button[i].touch_flag = 1;         /* ��¼���±�־ */
      
     // mode_button[i].draw_btn(&mode_button[i]);  /*�ػ水ť*/
      }        
      
    }
    else if(mode_button[i].touch_flag == 1) /* �����Ƴ��˰����ķ�Χ��֮ǰ�а��°�ť */
    {
      mode_button[i].touch_flag = 0;         /* ������±�־���ж�Ϊ�����*/
      
     // mode_button[i].draw_btn(&mode_button[i]);   /*�ػ水ť*/
    }
	}
}
void Mode_Button_Up(uint16_t x,uint16_t y)
{
	 uint8_t i; 
   for(i=0;i<MODE_BUTTON_NUM;i++)
   {
     /* �����ڰ�ť�����ͷ� */
      if((x<mode_button[i].end_x && x>mode_button[i].start_x && y<mode_button[i].end_y && y>mode_button[i].start_y))
      {        
        mode_button[i].touch_flag = 0;       /*�ͷŴ�����־*/
        
     //   mode_button[i].draw_btn(&mode_button[i]); /*�ػ水ť*/        
      
        mode_button[i].btn_command(&mode_button[i]);  /*ִ�а����Ĺ�������*/
        
        break;
      }
    }  
}

void Unlock_Button_Down(uint16_t x,uint16_t y)
{
	uint8_t i;
	 for(i=0;i<UNLOCK_BUTTON_NUM;i++)
	{
		if(x<=unlock_button[i].end_x && y<=unlock_button[i].end_y && y>=unlock_button[i].start_y && x>=unlock_button[i].start_x )
    {
      if(unlock_button[i].touch_flag == 0)     /*ԭ����״̬Ϊû�а��£������״̬*/
      {
      unlock_button[i].touch_flag = 1;         /* ��¼���±�־ */
      
     // unlock_button[i].draw_btn(&unlock_button[i]);  /*�ػ水ť*/
      }        
      
    }
    else if(unlock_button[i].touch_flag == 1) /* �����Ƴ��˰����ķ�Χ��֮ǰ�а��°�ť */
    {
      unlock_button[i].touch_flag = 0;         /* ������±�־���ж�Ϊ�����*/
      
     // unlock_button[i].draw_btn(&unlock_button[i]);   /*�ػ水ť*/
    }
	}
}
void Unlock_Button_Up(uint16_t x,uint16_t y)
{
	uint8_t i; 
   for(i=0;i<UNLOCK_BUTTON_NUM;i++)
   {
     /* �����ڰ�ť�����ͷ� */
      if((x<unlock_button[i].end_x && x>unlock_button[i].start_x && y<unlock_button[i].end_y && y>unlock_button[i].start_y))
      {        
        unlock_button[i].touch_flag = 0;       /*�ͷŴ�����־*/
        
     //   unlock_button[i].draw_btn(&unlock_button[i]); /*�ػ水ť*/        
      
        unlock_button[i].btn_command(&unlock_button[i]);  /*ִ�а����Ĺ�������*/
        
        break;
      }
    }  
}
void Setting_Button_Down(uint16_t x,uint16_t y)
{
	uint8_t i;
	 for(i=0;i<SETTING_BUTTON_NUM;i++)
	{
		if(x<=setting_button[i].end_x && y<=setting_button[i].end_y && y>=setting_button[i].start_y && x>=setting_button[i].start_x )
    {
      if(setting_button[i].touch_flag == 0)     /*ԭ����״̬Ϊû�а��£������״̬*/
      {
      setting_button[i].touch_flag = 1;         /* ��¼���±�־ */
      
     // setting_button[i].draw_btn(&setting_button[i]);  /*�ػ水ť*/
      }        
      
    }
    else if(setting_button[i].touch_flag == 1) /* �����Ƴ��˰����ķ�Χ��֮ǰ�а��°�ť */
    {
      setting_button[i].touch_flag = 0;         /* ������±�־���ж�Ϊ�����*/
      
     // setting_button[i].draw_btn(&setting_button[i]);   /*�ػ水ť*/
    }
	}
}
void Setting_Button_Up(uint16_t x,uint16_t y)
{
	uint8_t i; 
   for(i=0;i<SETTING_BUTTON_NUM;i++)
   {
     /* �����ڰ�ť�����ͷ� */
      if((x<setting_button[i].end_x && x>setting_button[i].start_x && y<setting_button[i].end_y && y>setting_button[i].start_y))
      {        
        setting_button[i].touch_flag = 0;       /*�ͷŴ�����־*/
        
     //   setting_button[i].draw_btn(&setting_button[i]); /*�ػ水ť*/        
      
        setting_button[i].btn_command(&setting_button[i]);  /*ִ�а����Ĺ�������*/
        
        break;
      }
    }  
}

